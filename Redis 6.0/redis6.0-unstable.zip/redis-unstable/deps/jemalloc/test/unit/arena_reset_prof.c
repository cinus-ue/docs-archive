#include "test/jemalloc_test.h"
#define ARENA_RESET_PROF_C_

#include "arena_reset.c"
